# PurePath free web prototype

Open `index.html` in a browser to preview. To install it on an iPhone Home Screen, upload the folder to any HTTPS static hosting provider (for example, GitHub Pages or Netlify), visit the published URL in Safari, then use Share > Add to Home Screen.

## Scope
- Select social apps for an accountability plan
- Request one-hour access (simulation)
- Simulate partner responses: No, Why?, Are you okay?, Approve 1 Hour
- Partner-created 6-digit demo PIN
- KJV encouragement and practical temptation support
- Local browser persistence and offline cache when hosted

## Important limitations
This prototype **does not block iPhone apps**, prevent reinstallation, securely authenticate partners, send push notifications, or collect subscriptions. The demo PIN is stored in browser localStorage, which is **not secure**. Do not use a real PIN. The approval timer only changes demo UI status, not device restrictions. A native iOS app with Apple's FamilyControls, ManagedSettings, DeviceActivity and a secure backend is required for real blocking/partner approval. Apple permission revocation and uninstall restrictions also apply.
